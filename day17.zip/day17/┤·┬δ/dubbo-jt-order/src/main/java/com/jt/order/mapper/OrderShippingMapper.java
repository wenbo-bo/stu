package com.jt.order.mapper;

import com.jt.common.mapper.SysMapper;
import com.jt.dubbo.pojo.OrderShipping;

public interface OrderShippingMapper extends SysMapper<OrderShipping>{


}